#' @useDynLib smash
#' @title Smash: SMoothing using Adaptive SHrinkage
#' @description This function performs nonparametric regression on univariate Poisson or Gaussian signals
#' @docType package
#' @name smash
NULL
